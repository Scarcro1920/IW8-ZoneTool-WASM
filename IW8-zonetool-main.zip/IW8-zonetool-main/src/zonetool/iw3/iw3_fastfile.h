#pragma once

#include "../convert/conv_xsurface.h"
#include "../dumpsrc/xmodel_dump.h"
#include "../iw8/replay_dynentity.h"
#include "../iw8/replay_havok.h"
#include "../iw8/replay_impact.h"
#include "../iw8/replay_navigation.h"
#include "../iw8/replay_render.h"
#include "../iw8/replay_sound.h"
#include "../iw8/replay_static_model_collision.h"
#include "../iw8/replay_sunshadow.h"
#include "iw3_vision.h"
#include "../iw8/replay_vfx.h"
#include "../iw8/replay_xanim.h"

#include <array>
#include <cstdint>
#include <filesystem>
#include <optional>
#include <set>
#include <string>
#include <unordered_map>
#include <vector>

namespace iw3
{
struct ImportOptions
{
    std::filesystem::path fastfile;
    std::string map;
    std::filesystem::path unlinker;
    std::filesystem::path scratchRoot;
    std::vector<std::filesystem::path> searchPaths;
    // Convert IW3 gametype visuals (flag props, headquarters radios).
    bool iw3ModeAssets{true};
    // IW3's look, or Replay's native fog/atmosphere/volumetrics (iw3_vision.h).
    MapStyle style{MapStyle::iw3};
};

struct PreparedXModel
{
    // IW3 source model and the conversion role it took (smodel, dynmodel,
    // entitymodel, fxmodel, partmodel), for the output ledger.
    std::string source, role;
    convert::xmodel::Iw8XModelRecord model;
    std::vector<conv_xsurf::Iw8Surfs> lods;
    iw8::havok::PhysicsAsset physicsAsset;
};

struct PreparedFxDependency
{
    std::string name;
    std::string type;
};

struct PreparedFxFloatRange
{
    float base{};
    float amplitude{};
};

struct PreparedFxIntRange
{
    std::int32_t base{};
    std::int32_t amplitude{};
};

struct PreparedFxVec3Range
{
    std::array<float, 3> base{};
    std::array<float, 3> amplitude{};
};

struct PreparedFxSpawn
{
    std::array<std::int32_t, 2> raw{};
    std::int32_t loopingIntervalMsec{};
    std::int32_t loopingCount{};
    PreparedFxIntRange oneShotCount{};
};

struct PreparedFxAtlas
{
    std::uint8_t behavior{};
    std::uint8_t index{};
    std::uint8_t fps{};
    std::uint8_t loopCount{};
    std::uint8_t colIndexBits{};
    std::uint8_t rowIndexBits{};
    std::int16_t entryCount{};
};

struct PreparedFxVisualState
{
    std::array<std::uint8_t, 4> color{};
    float rotationDelta{};
    float rotationTotal{};
    std::array<float, 2> size{};
    float scale{};
};

struct PreparedFxVisualSample
{
    PreparedFxVisualState base{};
    PreparedFxVisualState amplitude{};
};

struct PreparedFxVelocityFrame
{
    PreparedFxVec3Range velocity{};
    PreparedFxVec3Range totalDelta{};
};

struct PreparedFxVelocitySample
{
    PreparedFxVelocityFrame local{};
    PreparedFxVelocityFrame world{};
};

struct PreparedFxTrailVertex
{
    std::array<float, 2> position{};
    std::array<float, 2> normal{};
    float texCoord{};
};

struct PreparedFxTrail
{
    std::int32_t scrollTimeMsec{};
    std::int32_t repeatDist{};
    std::int32_t splitDist{};
    std::vector<PreparedFxTrailVertex> vertices;
    std::vector<std::uint16_t> indices;
};

enum class PreparedFxVisualKind : std::uint8_t
{
    none,
    material,
    xmodel,
    effect,
    sound,
    decal,
};

struct PreparedFxVisual
{
    PreparedFxVisualKind kind{PreparedFxVisualKind::none};
    // Ordinary visuals have zero or one name. A decal has exactly two material
    // slots, with an empty string preserving a source null pointer.
    std::vector<std::string> names;
};

struct PreparedFxElement
{
    std::int32_t flags{};
    // Drawn with an IW3 distortion material (stock Replay refraction state).
    bool distortion{};
    PreparedFxSpawn spawn{};
    PreparedFxFloatRange spawnRange{};
    PreparedFxFloatRange fadeInRange{};
    PreparedFxFloatRange fadeOutRange{};
    float spawnFrustumCullRadius{};
    PreparedFxIntRange spawnDelayMsec{};
    PreparedFxIntRange lifeSpanMsec{};
    std::array<PreparedFxFloatRange, 3> spawnOrigin{};
    PreparedFxFloatRange spawnOffsetRadius{};
    PreparedFxFloatRange spawnOffsetHeight{};
    std::array<PreparedFxFloatRange, 3> spawnAngles{};
    std::array<PreparedFxFloatRange, 3> angularVelocity{};
    PreparedFxFloatRange initialRotation{};
    PreparedFxFloatRange gravity{};
    PreparedFxFloatRange reflectionFactor{};
    PreparedFxAtlas atlas{};
    std::uint8_t type{};
    std::uint8_t visualCount{};
    std::uint8_t velocityIntervalCount{};
    std::uint8_t visualStateIntervalCount{};
    std::vector<PreparedFxVelocitySample> velocitySamples;
    std::vector<PreparedFxVisualSample> visualSamples;
    bool visualsPresent{};
    std::vector<PreparedFxVisual> visuals;
    std::array<float, 3> collisionMins{};
    std::array<float, 3> collisionMaxs{};
    std::string effectOnImpact;
    std::string effectOnDeath;
    std::string effectEmitted;
    PreparedFxFloatRange emitDist{};
    PreparedFxFloatRange emitDistVariance{};
    std::optional<PreparedFxTrail> trail;
    std::uint8_t sortOrder{};
    std::uint8_t lightingFrac{};
    std::uint8_t useItemClip{};
};

struct PreparedFx
{
    std::string name;
    std::filesystem::path sourcePath;
    std::int32_t flags{};
    std::int32_t totalSize{};
    std::int32_t msecLoopingLife{};
    std::array<std::uint32_t, 3> elementCounts{};
    std::vector<PreparedFxElement> elements;
    std::vector<PreparedFxDependency> dependencies;
};

struct PreparedRawFile
{
    std::string name;
    std::vector<std::uint8_t> data;
};

struct PreparedMap
{
    std::filesystem::path root;
    // Rung spacing of the map's ladder models; 0 keeps Replay's 12 (map.json
    // ladderRungDistance, applied by the DW client).
    float ladderRungDistance{};
    std::filesystem::path collision;
    std::filesystem::path footsteps;
    std::filesystem::path scratch;
    std::vector<PreparedXModel> xmodels;
    std::vector<PreparedRawFile> rawFiles;
    // IW3 animations the converted scripts play (vehicle destroy anims).
    std::vector<iw8::xanim::Anim> xanims;
    std::vector<PreparedFx> fxEffects;
    std::unordered_map<std::string, std::string> fxMaterialAliases;
    // Replay Particle_MaterialData per IW3 FX material (feather, falloff, eye offset).
    std::unordered_map<std::string, std::array<std::uint8_t, 192>> fxParticleMaterialData;
    std::vector<iw8::vfx::Effect> vfxEffects;
    std::string vfxLightDef;
    std::string smallGlassEffect;
    iw8::impact::EffectOverrides impactOverrides;
    replayrender::StaticModels staticModels;
    std::vector<iw8::staticmodelcollision::Model> staticModelCollisionModels;
    replaysunshadow::Scene shadowScene;
    std::vector<iw8::DynamicEntity> dynamicEntities;
    iw8::navigation::Source navigation;
    // IW8 GSC translated from the map's IW3 scripts (without the generated
    // minimap function), compiled with gsc-tool at package time.
    std::string mapScript;
    // Converted IW3 film grade (empty name without one); the generated Replay
    // vision file in rawFiles references it.
    std::string gradingClutName;
    std::vector<std::uint8_t> gradingClutPixels;
    // Converted IW3 sound aliases (always-loaded map bank), when any convert.
    std::optional<iw8::sound::Bank> soundBank;
    // Map-intro chyron (localize mp_chyron/<map>_<team>_<1..4> in eng_<map>):
    // line 2's clock, which the game follows with the running seconds
    // ("Day 1 10:30:"), and each team's unit (allies, axis; stock IW8 names).
    std::string chyronClock;
    std::array<std::string, 2> chyronUnits;

    PreparedMap() = default;
    PreparedMap(const PreparedMap &) = delete;
    PreparedMap &operator=(const PreparedMap &) = delete;
    PreparedMap(PreparedMap &&other) noexcept;
    PreparedMap &operator=(PreparedMap &&other) noexcept;
    ~PreparedMap();
};

PreparedMap PrepareFastfile(const ImportOptions &options);
} // namespace iw3
